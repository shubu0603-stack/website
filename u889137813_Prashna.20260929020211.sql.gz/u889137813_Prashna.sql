/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.20-11.8.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u889137813_Prashna
-- ------------------------------------------------------
-- Server version	11.8.9-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `doubts`
--

DROP TABLE IF EXISTS `doubts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doubts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `question_text` text NOT NULL,
  `status` enum('open','answered') NOT NULL DEFAULT 'open',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `answered_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `doubts_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doubts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `doubts` DISABLE KEYS */;
INSERT INTO `doubts` VALUES
(6,4,'Mathematics','A picture has 15cm 2.5cm dimension. A','answered','2026-03-07 13:02:23','2026-03-07 13:08:57'),
(7,4,'Mathematics','A picture has 15CM by 2.5cm dimension. A 1.5 cm broad frem is required to cover it. Find the cost of frem at₹1.50 per sq cm.','answered','2026-03-07 13:10:20','2026-03-07 13:29:17'),
(8,5,'Mathematics','The side of a square field is 400 find its perimeter in km','answered','2026-03-07 14:25:47','2026-03-07 14:34:52'),
(9,5,'Mathematics','What is a linear pair','answered','2026-03-10 03:44:57','2026-03-10 04:54:23'),
(10,5,'Mathematics','A labourer digs a pit 7.5 m Long.3m wide and 1.5m deep. How much earth is dug out from it','answered','2026-03-10 05:53:57','2026-03-10 06:21:37'),
(11,5,'Mathematics','One of the acute angle of a right triangle is of measure 35 degree what is the measure of the other acute angle','answered','2026-03-11 07:54:34','2026-03-14 07:28:41'),
(12,5,'EVS/Science','How are igneous rock formed','answered','2026-03-15 05:04:08','2026-03-15 05:14:30'),
(13,5,'EVS/Science','Differentiate between sparin and fracture','answered','2026-03-16 05:17:43','2026-03-16 12:56:29'),
(14,5,'EVS/Science','Differentiate between sedimention and evaporation','answered','2026-03-16 14:54:42','2026-03-16 15:00:03'),
(15,6,'Other','I want to know more about your system','open','2026-04-16 14:10:02',NULL),
(16,6,'General','Let me know more','open','2026-04-16 14:11:22',NULL);
/*!40000 ALTER TABLE `doubts` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `attempt_time` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES
(1,'2401:4900:a60e:7431:d13:d2dc:b826:8f84','7455859560','2026-06-22 18:30:47');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `replies`
--

DROP TABLE IF EXISTS `replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doubt_id` int(11) NOT NULL,
  `mentor_id` int(11) NOT NULL,
  `answer_text` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `doubt_id` (`doubt_id`),
  KEY `mentor_id` (`mentor_id`),
  CONSTRAINT `replies_ibfk_1` FOREIGN KEY (`doubt_id`) REFERENCES `doubts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `replies_ibfk_2` FOREIGN KEY (`mentor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replies`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
INSERT INTO `replies` VALUES
(6,6,1,'Area = Length × Breadth\r\n\r\n= 15 cm × 2.5 cm\r\n= 37.5 cm²\r\n\r\nAnswer: 37.5 square centimeters','2026-03-07 13:08:57'),
(7,7,1,'Let’s solve it step by step 😊\r\n\r\n1. Given\r\n\r\nLength of picture = 15 cm\r\n\r\nBreadth of picture = 2.5 cm\r\n\r\nWidth of frame = 1.5 cm\r\n\r\nCost = ₹1.50 per sq cm\r\n\r\n2. Find the outer size after adding the frame\r\n\r\nThe frame is on both sides, so we add 1.5 cm twice.\r\n\r\nOuter Length\r\n= 15 + 1.5 + 1.5\r\n= 18 cm\r\n\r\nOuter Breadth\r\n= 2.5 + 1.5 + 1.5\r\n= 5.5 cm\r\n\r\n3. Area of the outer rectangle\r\n\r\nArea = Length × Breadth\r\n\r\n= 18 × 5.5\r\n= 99 sq cm\r\n\r\n4. Area of the picture\r\n\r\n= 15 × 2.5\r\n= 37.5 sq cm\r\n\r\n5. Area of the frame\r\n\r\nFrame area = Outer area − Picture area\r\n\r\n= 99 − 37.5\r\n= 61.5 sq cm\r\n\r\n6. Find the cost\r\n\r\nCost per sq cm = ₹1.50\r\n\r\nTotal cost\r\n= 61.5 × 1.50\r\n= ₹92.25\r\n\r\n✅ Final Answer:\r\nThe cost of the frame = ₹92.25','2026-03-07 13:29:17'),
(8,8,1,'Side of the square = 400 m\r\n\r\nPerimeter of a square = 4 × Side\r\n\r\n= 4 × 400  \r\n= 1600 m\r\n\r\nNow convert meters into kilometers.\r\n\r\n1000 m = 1 km\r\n\r\n1600 m = 1600 ÷ 1000  \r\n= 1.6 km\r\n\r\nAnswer: The perimeter of the square field is 1.6 km.','2026-03-07 14:34:52'),
(9,9,1,'When two angles are next to each other and they make a straight line, they are called a Linear Pair.\r\n\r\nSimple definition:\r\nA linear pair is when two angles together form a straight line (180°).\r\n\r\nExample\r\nImagine a straight road.\r\nNow draw a line crossing the road.\r\n\r\nThis makes two angles side by side.\r\n\r\nIf one angle is 70°, the other angle will be:\r\n180° − 70° = 110°\r\nSo 70° and 110° form a Linear Pair.','2026-03-10 04:54:23'),
(10,10,1,'To find the amount of earth dug out, we need to find the Volume of the pit.\r\n\r\nFormula:\r\n\r\nVolume = Length × Width × Depth\r\n\r\n\r\nStep-by-Step Solution:\r\n Length 7.5m Width 3m Depth 1.5m\r\nVolume = 7.5 × 3 × 1.5\r\n= 7.5 × 3 = 22.5\r\n= 22.5 × 1.5 = 33.75\r\n\r\nAnswer:\r\n33.75 cubic metres (m³) of earth is dug out from the pit.','2026-03-10 06:21:37'),
(11,11,1,'In a right triangle, the sum of all internal angles is always 180°. Since it is a right triangle, one angle is exactly 90°.Because the three angles must add up to 180°, the two acute angles must together add up to 90° (this makes them complementary angles).To find the measure of the other acute angle, you simply subtract the known acute angle from 90°:$$90° - 35° = 55°$$The measure of the other acute angle is 55°.','2026-03-14 07:28:41'),
(12,12,1,'Igneous rocks are formed when hot melted rock (magma or lava) cools down and becomes solid.\r\n\r\n\r\nInside the Earth, rocks melt because of very high temperature.\r\n\r\nThis melted rock is called magma.\r\n\r\nWhen magma comes out of a volcano, it is called lava.\r\n\r\nWhen the magma or lava cools and hardens, it forms igneous rocks.','2026-03-15 05:14:30'),
(13,13,1,'1. Strain\r\n\r\nMeaning: Change in the shape or size of a rock due to stress.\r\n\r\nThe rock bends, stretches, or compresses but does not break.\r\n\r\nThis usually happens when rocks are deep inside the Earth where pressure and temperature are high.\r\n\r\nExample: Rock layers folding in mountains.\r\n\r\n2. Fracture\r\n\r\nMeaning: When a rock breaks or cracks due to stress.\r\n\r\nThe rock cannot withstand the stress, so it splits or breaks.\r\n\r\nHappens more often near the Earth\'s surface where rocks are brittle.\r\n\r\nExample: Cracks in rocks or faults during earthquakes.','2026-03-16 12:56:29'),
(14,14,1,'Sedimentation:\r\nSedimentation is the process in which heavier, insoluble particles present in a liquid settle down at the bottom of the container when the mixture is left undisturbed. It is mainly used to separate insoluble solids from liquids. For example, when muddy water is left still for some time, the mud settles at the bottom.\r\n\r\nEvaporation:\r\nEvaporation is the process in which a liquid changes into vapour due to heat or increase in temperature. It is used to separate dissolved solids from liquids. For example, when salt water is heated, the water evaporates and salt is left behind.','2026-03-16 15:00:03');
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('student','mentor') NOT NULL DEFAULT 'student',
  `name` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `verification_token` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `refresh_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'mentor','Anisul Islam','6002813464','ianisul768@gmail.com','2026-06-20 12:11:33','$2y$10$U3si.80XykSM43B9DVj53uMksmkJcAg9j0u/dQFLbS8HArq2ZjAae',NULL,NULL,NULL,'2026-02-28 08:27:05',NULL),
(2,'student','Ani','6002813462','islamanisul87@gmail.com','2026-06-20 12:11:33','$2y$10$pUSj.oYufc2u2N0oUUFS3OCODsw.wTBxIBmxkRcfhBiT77YmDcYia',NULL,NULL,NULL,'2026-02-28 08:28:27',NULL),
(4,'student','Aryanandini','8103050020','ckstk1990@gmail.com','2026-06-20 12:11:33','$2y$10$4r4gFbu./XOi1cgnsLID9eD4nW/FbJxfH79iHKfA3LIq1tOo5CjKu',NULL,NULL,NULL,'2026-03-07 12:58:29',NULL),
(5,'student','Aryanandini','9576143165','aryanandini120@gmail.com','2026-06-20 12:11:33','$2y$10$KmWlpfFLAgfR53m6Wo0tROHXU1tprgS5LQ8UZ0DiKylilM/IcQqTK',NULL,NULL,NULL,'2026-03-07 14:17:50',NULL),
(6,'student','Hrishi Kalita','8638207370','ktrailokya@gmail.com','2026-06-20 12:11:33','$2y$10$KYBD.Vvsmw7GMHE7QUcfP.gJXAMSrBikn433nk4frwUXdL/XAEE8i',NULL,NULL,NULL,'2026-04-16 14:08:54',NULL),
(7,'student','Smita Agrawal','7009281830','smitaagrawal1975@gmail.com','2026-06-20 12:11:33','$2y$10$oK/NJzgow8FrDVImFOdoaOuKGf8fT8Idpcg2KKJfvF47ZnBbGugim',NULL,NULL,NULL,'2026-04-25 10:38:45',NULL),
(8,'student','Upayaan das','9593183349','nabamighosh9593@gmail.com','2026-06-20 12:11:33','$2y$10$VPiS0QuTwX/YHe3MWWL4POIz1hzdzpQ7jkFxnT22keDgGRzTn9bry',NULL,NULL,NULL,'2026-06-13 12:16:36',NULL),
(9,'student','shivanshu','7676798650','shivanshushakya7@gmail.com','2026-06-20 12:11:33','$2y$10$Y5xRR4COCfHwwYft6nMYLu814Z3I.lFg7CfX6Nb/ZHvt/O4Ydhiii',NULL,NULL,NULL,'2026-06-15 05:10:08',NULL),
(10,'student','Hshs','01212121212','moontontlol321@gmail.com','2026-06-28 14:57:05','$argon2id$v=19$m=65536,t=4,p=2$b0d2Uk5UQ1NZOXEzaW13Zw$eo2OFfxlwYZ3Qr19YSXarHjcq7RcNPpgeKDBZmYPBmk',NULL,NULL,NULL,'2026-06-28 14:56:49','0a9b5d85018ffb7d3ab75c945e9b2c4b7e1f5937a7712daf5e54c4b3df95bcf8');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'u889137813_Prashna'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-09-29  2:03:27
